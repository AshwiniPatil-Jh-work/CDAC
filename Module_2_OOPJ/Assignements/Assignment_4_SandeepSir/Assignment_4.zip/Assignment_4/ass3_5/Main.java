package ass3_5;

public class Main {

	public static void main(String[] args) {
		TollBoothRevenueManager obj1 = new TollBoothRevenueManager();
		
		obj1.acceptRecord();
		obj1.setTollRate();
		obj1.calculateRevenue();
		
	}

}