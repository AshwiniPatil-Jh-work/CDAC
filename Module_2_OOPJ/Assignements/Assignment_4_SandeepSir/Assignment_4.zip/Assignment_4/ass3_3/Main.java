package ass3_3;

public class Main {
				public static void main(String[] args) {
								
				Discount obj1 = new Discount();
				obj1.acceptRecord();
				obj1.calculateDiscount();
				obj1.printRecord();
	
		}
}
