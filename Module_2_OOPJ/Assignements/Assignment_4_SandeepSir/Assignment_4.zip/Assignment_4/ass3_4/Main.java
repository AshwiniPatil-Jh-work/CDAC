package ass3_4;
public class Main {

		public static void main(String[] args) {
			
			LoadCalculator L1 = new LoadCalculator();			
			L1.acceptRecord();
			L1.calculateMonthlyPayment();
			
		}

}
