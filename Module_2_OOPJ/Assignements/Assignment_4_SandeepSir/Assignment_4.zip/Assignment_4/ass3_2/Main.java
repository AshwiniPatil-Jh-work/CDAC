package ass3_2;

public class Main {

	public static void main(String[] args) {
		
				CompoundInterestCalculator obj1 = new CompoundInterestCalculator();
				
				obj1.acceptRecord();
				obj1.calculateFutureValue();
				obj1.printRecord();
			}

		}
	